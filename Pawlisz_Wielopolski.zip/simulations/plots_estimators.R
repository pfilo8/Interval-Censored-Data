library(tidyverse)
library(ggplot2)
library(latex2exp)
library(patchwork)

source('src/generator.R')
source('src/plots.R')


lambda_vector <- seq(1, 10, 1)
nu_vector <- seq(1, 10, 1)
mc <- seq(1, 100, 1)

lambdas <- c()
nus <- c()
means <- c()
vars <- c()
bias <- c()
mean_sq <- c()


for (j in 1:length(lambda_vector)){
  for (k in 1:length(nu_vector)){
    est_values <- c()
    for (i in mc){
      a <- turnbull(lambda_vector[j], nu_vector[k])
      if (a != Inf){ #stymacja �redniej teoretycznie mo�e wyj�� r�wna niesko�czono�ci gdy dla ostatniej warto�ci warto�� b�dzie niezerowa warto��
        est_values <- c(est_values, a)
      }
    }
    lambdas <- c(lambdas, lambda_vector[j])
    nus <- c(nus, nu_vector[k])
    means <- c(means, mean(est_values))
    vars <- c(vars, var(est_values))
    bias <- c(bias, mean(est_values - lambda_vector[j]))
    mean_sq <-  c(mean_sq, mean((est_values - lambda_vector[j])^2))
  }
}


write.csv(data.frame(lambdas, nus, means), file="results/means_turnbull.csv",row.names=FALSE)
write.csv(data.frame(lambdas, nus, vars), file="results/vars_turnbull.csv",row.names=FALSE)
write.csv(data.frame(lambdas, nus, bias), file="results/bias_turnbull.csv",row.names=FALSE)
write.csv(data.frame(lambdas, nus, mean_sq), file="results/mean_sq_turnbull.csv",row.names=FALSE)


means<-read.csv("results/means.csv")
vars<-read.csv("results/vars.csv")
bias<-read.csv("results/bias.csv")
mean_sq<-read.csv("results/mean_sq.csv")

means  %>%
  ggplot(aes(x = lambdas, y = means, group = nus, color = nus)) +
  geom_point() +
  geom_line() +
  geom_line(aes(y = lambdas), color = "red", linetype = "dotted") +
  xlab(TeX('$\\lambda$ - lightbulb failure rate')) +
  ylab(TeX('Mean of naive estimator of $\\lambda$')) +
  ggtitle('Mean of naive estimator') +
  theme_minimal()


vars  %>%
  ggplot(aes(x = lambdas, y = vars, group = nus, color = nus)) +
  geom_point() +
  geom_line() +
  xlab(TeX('$\\lambda$ - lightbulb failure rate')) +
  ylab(TeX('Variance  of naive estimator of $\\lambda$')) +
  ggtitle('Variance of naive estimator') +
  theme_minimal()

bias %>%
  ggplot(aes(x = lambdas, y = bias, group = nus, color = nus)) +
  geom_point() +
  geom_line() +
  geom_line(aes(y = 0), color = "red", linetype = "dotted") +
  xlab(TeX('$\\lambda$ - lightbulb failure rate')) +
  ylab(TeX('Bias of naive estimator of $\\lambda$')) +
  ggtitle('Bias of naive estimator') +
  theme_minimal()

mean_sq  %>%
  ggplot(aes(x = lambdas, y = mean_sq, group = nus, color = nus)) +  geom_point() +
  geom_line() +
  xlab(TeX('$\\lambda$ - lightbulb failure rate')) +
  ylab(TeX('Mean square error of naive estimator of $\\lambda$')) +
  ggtitle('Mean square error of naive estimator') +
  theme_minimal()

